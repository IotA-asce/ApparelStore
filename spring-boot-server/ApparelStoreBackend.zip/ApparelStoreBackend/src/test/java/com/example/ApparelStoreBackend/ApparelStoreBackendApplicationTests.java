package com.example.ApparelStoreBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApparelStoreBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
